﻿
namespace PWMS
{
    partial class F_Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Menu_1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Folk = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_EmployeeGenre = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Kultur = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Visage = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Branch = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Laborage = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Business = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Duthcall = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_RPKind = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_WordPad = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_3 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_ClewBirthday = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_ClewBargain = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_4 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Stuffbusic = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Stufind = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Stusum = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_5 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_DayWordPad = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_AddressBook = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_6 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Back = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Clear = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_7 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Counter = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_WordBook = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_8 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_NewLogon = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Setup = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_9 = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_10 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Help = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.基本数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.民族类别设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职工类别设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.文化程度设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.正治面貌设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.部门类别设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.工资类别设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职务类别设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职称类别设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.奖惩类别设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.职工提示设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.合同提示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生日提示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Button_Stuffbasic = new System.Windows.Forms.ToolStripButton();
            this.Button_Stufind = new System.Windows.Forms.ToolStripButton();
            this.Button_ClewBargain = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripSeparator();
            this.Botton_AddressBook = new System.Windows.Forms.ToolStripButton();
            this.Botton_DayWordPad = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Button_Close = new System.Windows.Forms.ToolStripButton();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_1,
            this.Menu_4,
            this.Menu_5,
            this.Menu_6,
            this.Menu_7,
            this.Menu_8,
            this.Menu_10});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1024, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Menu_1
            // 
            this.Menu_1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_2,
            this.Menu_3});
            this.Menu_1.Name = "Menu_1";
            this.Menu_1.Size = new System.Drawing.Size(113, 24);
            this.Menu_1.Text = "基础信息管理";
            // 
            // Menu_2
            // 
            this.Menu_2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Folk,
            this.Tool_EmployeeGenre,
            this.Tool_Kultur,
            this.Tool_Visage,
            this.Tool_Branch,
            this.Tool_Laborage,
            this.Tool_Business,
            this.Tool_Duthcall,
            this.Tool_RPKind,
            this.Tool_WordPad});
            this.Menu_2.Name = "Menu_2";
            this.Menu_2.Size = new System.Drawing.Size(182, 26);
            this.Menu_2.Text = "基础数据";
            // 
            // Tool_Folk
            // 
            this.Tool_Folk.Name = "Tool_Folk";
            this.Tool_Folk.Size = new System.Drawing.Size(197, 26);
            this.Tool_Folk.Text = "民族类别设置";
            this.Tool_Folk.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_EmployeeGenre
            // 
            this.Tool_EmployeeGenre.Name = "Tool_EmployeeGenre";
            this.Tool_EmployeeGenre.Size = new System.Drawing.Size(197, 26);
            this.Tool_EmployeeGenre.Text = "职工类别设置";
            this.Tool_EmployeeGenre.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Kultur
            // 
            this.Tool_Kultur.Name = "Tool_Kultur";
            this.Tool_Kultur.Size = new System.Drawing.Size(197, 26);
            this.Tool_Kultur.Text = "文化程度设置";
            this.Tool_Kultur.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Visage
            // 
            this.Tool_Visage.Name = "Tool_Visage";
            this.Tool_Visage.Size = new System.Drawing.Size(197, 26);
            this.Tool_Visage.Text = "政治面貌设置";
            this.Tool_Visage.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Branch
            // 
            this.Tool_Branch.Name = "Tool_Branch";
            this.Tool_Branch.Size = new System.Drawing.Size(197, 26);
            this.Tool_Branch.Text = "部门类别设置";
            this.Tool_Branch.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Laborage
            // 
            this.Tool_Laborage.Name = "Tool_Laborage";
            this.Tool_Laborage.Size = new System.Drawing.Size(197, 26);
            this.Tool_Laborage.Text = "工资类别设置";
            this.Tool_Laborage.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Business
            // 
            this.Tool_Business.Name = "Tool_Business";
            this.Tool_Business.Size = new System.Drawing.Size(197, 26);
            this.Tool_Business.Text = "职务类别设置";
            this.Tool_Business.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_Duthcall
            // 
            this.Tool_Duthcall.Name = "Tool_Duthcall";
            this.Tool_Duthcall.Size = new System.Drawing.Size(197, 26);
            this.Tool_Duthcall.Text = "职称类别设置";
            this.Tool_Duthcall.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_RPKind
            // 
            this.Tool_RPKind.Name = "Tool_RPKind";
            this.Tool_RPKind.Size = new System.Drawing.Size(197, 26);
            this.Tool_RPKind.Text = "奖惩类别设置";
            this.Tool_RPKind.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Tool_WordPad
            // 
            this.Tool_WordPad.Name = "Tool_WordPad";
            this.Tool_WordPad.Size = new System.Drawing.Size(197, 26);
            this.Tool_WordPad.Text = "记事本类别设置";
            this.Tool_WordPad.Click += new System.EventHandler(this.Tool_Folk_Click);
            // 
            // Menu_3
            // 
            this.Menu_3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_ClewBirthday,
            this.Tool_ClewBargain});
            this.Menu_3.Name = "Menu_3";
            this.Menu_3.Size = new System.Drawing.Size(182, 26);
            this.Menu_3.Text = "员工提示信息";
            // 
            // Tool_ClewBirthday
            // 
            this.Tool_ClewBirthday.Name = "Tool_ClewBirthday";
            this.Tool_ClewBirthday.Size = new System.Drawing.Size(182, 26);
            this.Tool_ClewBirthday.Tag = "1";
            this.Tool_ClewBirthday.Text = "员工生日提示";
            this.Tool_ClewBirthday.Click += new System.EventHandler(this.Tool_ClewBirthday_Click);
            // 
            // Tool_ClewBargain
            // 
            this.Tool_ClewBargain.Name = "Tool_ClewBargain";
            this.Tool_ClewBargain.Size = new System.Drawing.Size(182, 26);
            this.Tool_ClewBargain.Tag = "2";
            this.Tool_ClewBargain.Text = "员工合同提示";
            this.Tool_ClewBargain.Click += new System.EventHandler(this.Tool_ClewBargain_Click);
            // 
            // Menu_4
            // 
            this.Menu_4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Stuffbusic,
            this.Tool_Stufind,
            this.Tool_Stusum});
            this.Menu_4.Name = "Menu_4";
            this.Menu_4.Size = new System.Drawing.Size(83, 24);
            this.Menu_4.Text = "人事管理";
            // 
            // Tool_Stuffbasic
            // 
            this.Tool_Stuffbusic.Name = "Tool_Stuffbusic";
            this.Tool_Stuffbusic.Size = new System.Drawing.Size(182, 26);
            this.Tool_Stuffbusic.Text = "人事档案管理";
            this.Tool_Stuffbusic.Click += new System.EventHandler(this.Tool_Stuffbusic_Click);
            // 
            // Tool_Stufind
            // 
            this.Tool_Stufind.Name = "Tool_Stufind";
            this.Tool_Stufind.Size = new System.Drawing.Size(182, 26);
            this.Tool_Stufind.Text = "人事资料查询";
            this.Tool_Stufind.Click += new System.EventHandler(this.Tool_Stufind_Click);
            // 
            // Tool_Stusum
            // 
            this.Tool_Stusum.Name = "Tool_Stusum";
            this.Tool_Stusum.Size = new System.Drawing.Size(182, 26);
            this.Tool_Stusum.Text = "人事资料统计";
            this.Tool_Stusum.Click += new System.EventHandler(this.Tool_Stusum_Click);
            // 
            // Menu_5
            // 
            this.Menu_5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_DayWordPad,
            this.Tool_AddressBook});
            this.Menu_5.Name = "Menu_5";
            this.Menu_5.Size = new System.Drawing.Size(83, 24);
            this.Menu_5.Text = "备忘记录";
            // 
            // Tool_DayWordPad
            // 
            this.Tool_DayWordPad.Name = "Tool_DayWordPad";
            this.Tool_DayWordPad.Size = new System.Drawing.Size(152, 26);
            this.Tool_DayWordPad.Text = "日常记事";
            this.Tool_DayWordPad.Click += new System.EventHandler(this.Tool_DayWordPad_Click);
            // 
            // Tool_AddressBook
            // 
            this.Tool_AddressBook.Name = "Tool_AddressBook";
            this.Tool_AddressBook.Size = new System.Drawing.Size(152, 26);
            this.Tool_AddressBook.Text = "通讯录";
            this.Tool_AddressBook.Click += new System.EventHandler(this.Tool_AddressBook_Click);
            // 
            // Menu_6
            // 
            this.Menu_6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Back,
            this.Tool_Clear});
            this.Menu_6.Name = "Menu_6";
            this.Menu_6.Size = new System.Drawing.Size(98, 24);
            this.Menu_6.Text = "数据库维护";
            // 
            // Tool_Back
            // 
            this.Tool_Back.Name = "Tool_Back";
            this.Tool_Back.Size = new System.Drawing.Size(203, 26);
            this.Tool_Back.Text = "备份/还原数据库";
            this.Tool_Back.Click += new System.EventHandler(this.Tool_Back_Click);
            // 
            // Tool_Clear
            // 
            this.Tool_Clear.Name = "Tool_Clear";
            this.Tool_Clear.Size = new System.Drawing.Size(203, 26);
            this.Tool_Clear.Text = "清空数据库";
            this.Tool_Clear.Click += new System.EventHandler(this.Tool_Clear_Click);
            // 
            // Menu_7
            // 
            this.Menu_7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Counter,
            this.Tool_WordBook});
            this.Menu_7.Name = "Menu_7";
            this.Menu_7.Size = new System.Drawing.Size(83, 24);
            this.Menu_7.Text = "工具管理";
            // 
            // Tool_Counter
            // 
            this.Tool_Counter.Name = "Tool_Counter";
            this.Tool_Counter.Size = new System.Drawing.Size(137, 26);
            this.Tool_Counter.Text = "计算器";
            this.Tool_Counter.Click += new System.EventHandler(this.Tool_Counter_Click);
            // 
            // Tool_WordBook
            // 
            this.Tool_WordBook.Name = "Tool_WordBook";
            this.Tool_WordBook.Size = new System.Drawing.Size(137, 26);
            this.Tool_WordBook.Text = "记事本";
            this.Tool_WordBook.Click += new System.EventHandler(this.Tool_WordBook_Click);
            // 
            // Menu_8
            // 
            this.Menu_8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_NewLogon,
            this.Tool_Setup,
            this.Menu_9});
            this.Menu_8.Name = "Menu_8";
            this.Menu_8.Size = new System.Drawing.Size(83, 24);
            this.Menu_8.Text = "系统管理";
            // 
            // Tool_NewLogon
            // 
            this.Tool_NewLogon.Name = "Tool_NewLogon";
            this.Tool_NewLogon.Size = new System.Drawing.Size(152, 26);
            this.Tool_NewLogon.Text = "重新登录";
            this.Tool_NewLogon.Click += new System.EventHandler(this.Tool_NewLogon_Click);
            // 
            // Tool_Setup
            // 
            this.Tool_Setup.Name = "Tool_Setup";
            this.Tool_Setup.Size = new System.Drawing.Size(152, 26);
            this.Tool_Setup.Text = "用户设置";
            this.Tool_Setup.Click += new System.EventHandler(this.Tool_Setup_Click);
            // 
            // Menu_9
            // 
            this.Menu_9.Name = "Menu_9";
            this.Menu_9.Size = new System.Drawing.Size(152, 26);
            this.Menu_9.Text = "系统退出";
            this.Menu_9.Click += new System.EventHandler(this.系统退出ToolStripMenuItem_Click);
            // 
            // Menu_10
            // 
            this.Menu_10.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Help});
            this.Menu_10.Name = "Menu_10";
            this.Menu_10.Size = new System.Drawing.Size(53, 24);
            this.Menu_10.Text = "帮助";
            // 
            // Tool_Help
            // 
            this.Tool_Help.Name = "Tool_Help";
            this.Tool_Help.Size = new System.Drawing.Size(152, 26);
            this.Tool_Help.Text = "系统帮助";
            this.Tool_Help.Click += new System.EventHandler(this.Tool_Help_Click);
            // 
            // 帮助ToolStripMenuItem1
            // 
            this.帮助ToolStripMenuItem1.Name = "帮助ToolStripMenuItem1";
            this.帮助ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.帮助ToolStripMenuItem1.Text = "帮助";
            // 
            // 基本数据ToolStripMenuItem
            // 
            this.基本数据ToolStripMenuItem.Name = "基本数据ToolStripMenuItem";
            this.基本数据ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.基本数据ToolStripMenuItem.Text = "基本数据";
            // 
            // 民族类别设置ToolStripMenuItem
            // 
            this.民族类别设置ToolStripMenuItem.Name = "民族类别设置ToolStripMenuItem";
            this.民族类别设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.民族类别设置ToolStripMenuItem.Text = "民族类别设置";
            // 
            // 职工类别设置ToolStripMenuItem
            // 
            this.职工类别设置ToolStripMenuItem.Name = "职工类别设置ToolStripMenuItem";
            this.职工类别设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.职工类别设置ToolStripMenuItem.Text = "职工类别设置";
            // 
            // 文化程度设置ToolStripMenuItem
            // 
            this.文化程度设置ToolStripMenuItem.Name = "文化程度设置ToolStripMenuItem";
            this.文化程度设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.文化程度设置ToolStripMenuItem.Text = "文化程度设置";
            // 
            // 正治面貌设置ToolStripMenuItem
            // 
            this.正治面貌设置ToolStripMenuItem.Name = "正治面貌设置ToolStripMenuItem";
            this.正治面貌设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.正治面貌设置ToolStripMenuItem.Text = "正治面貌设置";
            // 
            // 部门类别设置ToolStripMenuItem
            // 
            this.部门类别设置ToolStripMenuItem.Name = "部门类别设置ToolStripMenuItem";
            this.部门类别设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.部门类别设置ToolStripMenuItem.Text = "部门类别设置";
            // 
            // 工资类别设置ToolStripMenuItem
            // 
            this.工资类别设置ToolStripMenuItem.Name = "工资类别设置ToolStripMenuItem";
            this.工资类别设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.工资类别设置ToolStripMenuItem.Text = "工资类别设置";
            // 
            // 职务类别设置ToolStripMenuItem
            // 
            this.职务类别设置ToolStripMenuItem.Name = "职务类别设置ToolStripMenuItem";
            this.职务类别设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.职务类别设置ToolStripMenuItem.Text = "职务类别设置";
            // 
            // 职称类别设置ToolStripMenuItem
            // 
            this.职称类别设置ToolStripMenuItem.Name = "职称类别设置ToolStripMenuItem";
            this.职称类别设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.职称类别设置ToolStripMenuItem.Text = "职称类别设置";
            // 
            // 奖惩类别设置ToolStripMenuItem
            // 
            this.奖惩类别设置ToolStripMenuItem.Name = "奖惩类别设置ToolStripMenuItem";
            this.奖惩类别设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.奖惩类别设置ToolStripMenuItem.Text = "奖惩类别设置";
            // 
            // 职工提示设置ToolStripMenuItem
            // 
            this.职工提示设置ToolStripMenuItem.Name = "职工提示设置ToolStripMenuItem";
            this.职工提示设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.职工提示设置ToolStripMenuItem.Text = "职工提示设置";
            // 
            // 合同提示ToolStripMenuItem
            // 
            this.合同提示ToolStripMenuItem.Name = "合同提示ToolStripMenuItem";
            this.合同提示ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.合同提示ToolStripMenuItem.Text = "合同提示";
            // 
            // 生日提示ToolStripMenuItem
            // 
            this.生日提示ToolStripMenuItem.Name = "生日提示ToolStripMenuItem";
            this.生日提示ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.生日提示ToolStripMenuItem.Text = "生日提示";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 552);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1024, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(205, 20);
            this.toolStripStatusLabel1.Text = "||欢迎使用企业人事管理系统||";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(159, 20);
            this.toolStripStatusLabel2.Text = "　当前登录用户：　　";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(167, 20);
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Button_Stuffbasic,
            this.Button_Stufind,
            this.Button_ClewBargain,
            this.toolStripButton4,
            this.Botton_AddressBook,
            this.Botton_DayWordPad,
            this.toolStripSeparator1,
            this.Button_Close});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1024, 27);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Button_Stuffbasic
            // 
            this.Button_Stuffbasic.Image = ((System.Drawing.Image)(resources.GetObject("Button_Stuffbasic.Image")));
            this.Button_Stuffbasic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_Stuffbasic.Name = "Button_Stuffbasic";
            this.Button_Stuffbasic.Size = new System.Drawing.Size(123, 24);
            this.Button_Stuffbasic.Text = "人事档案管理";
            this.Button_Stuffbasic.Click += new System.EventHandler(this.Button_Stuffbasic_Click);
            // 
            // Button_Stufind
            // 
            this.Button_Stufind.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_Stufind.Name = "Button_Stufind";
            this.Button_Stufind.Size = new System.Drawing.Size(103, 24);
            this.Button_Stufind.Text = "人事资料查询";
            this.Button_Stufind.Click += new System.EventHandler(this.Button_Stufind_Click);
            // 
            // Button_ClewBargain
            // 
            this.Button_ClewBargain.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_ClewBargain.Name = "Button_ClewBargain";
            this.Button_ClewBargain.Size = new System.Drawing.Size(103, 24);
            this.Button_ClewBargain.Text = "员工合同提示";
            this.Button_ClewBargain.Click += new System.EventHandler(this.Button_ClewBargain_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(6, 27);
            // 
            // Botton_AddressBook
            // 
            this.Botton_AddressBook.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botton_AddressBook.Name = "Botton_AddressBook";
            this.Botton_AddressBook.Size = new System.Drawing.Size(58, 24);
            this.Botton_AddressBook.Text = "通讯录";
            this.Botton_AddressBook.Click += new System.EventHandler(this.Botton_AddressBook_Click);
            // 
            // Botton_DayWordPad
            // 
            this.Botton_DayWordPad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botton_DayWordPad.Name = "Botton_DayWordPad";
            this.Botton_DayWordPad.Size = new System.Drawing.Size(73, 24);
            this.Botton_DayWordPad.Text = "日常记事";
            this.Botton_DayWordPad.Click += new System.EventHandler(this.Botton_DayWordPad_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // Button_Close
            // 
            this.Button_Close.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_Close.Name = "Button_Close";
            this.Button_Close.Size = new System.Drawing.Size(73, 24);
            this.Button_Close.Text = "退出系统";
            this.Button_Close.Click += new System.EventHandler(this.Button_Close_Click);
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeView1.Location = new System.Drawing.Point(0, 55);
            this.treeView1.Margin = new System.Windows.Forms.Padding(4);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(271, 497);
            this.treeView1.TabIndex = 3;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(271, 55);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(753, 497);
            this.panel1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(753, 497);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // F_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 578);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "F_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "企业人事管理系统";
            this.Activated += new System.EventHandler(this.F_Main_Activated);
            this.Load += new System.EventHandler(this.F_Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Menu_1;
        private System.Windows.Forms.ToolStripMenuItem Menu_4;
        private System.Windows.Forms.ToolStripMenuItem Menu_5;
        private System.Windows.Forms.ToolStripMenuItem Menu_6;
        private System.Windows.Forms.ToolStripMenuItem Menu_7;
        private System.Windows.Forms.ToolStripMenuItem Menu_8;
        private System.Windows.Forms.ToolStripMenuItem Menu_10;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 基本数据ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 民族类别设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 职工类别设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 文化程度设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 正治面貌设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 部门类别设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 工资类别设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 职务类别设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 职称类别设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 奖惩类别设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 职工提示设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 合同提示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生日提示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Tool_Stuffbusic;
        private System.Windows.Forms.ToolStripMenuItem Tool_Stufind;
        private System.Windows.Forms.ToolStripMenuItem Tool_Stusum;
        private System.Windows.Forms.ToolStripMenuItem Tool_DayWordPad;
        private System.Windows.Forms.ToolStripMenuItem Tool_AddressBook;
        private System.Windows.Forms.ToolStripMenuItem Tool_Back;
        private System.Windows.Forms.ToolStripMenuItem Tool_Clear;
        private System.Windows.Forms.ToolStripMenuItem Tool_Counter;
        private System.Windows.Forms.ToolStripMenuItem Tool_WordBook;
        private System.Windows.Forms.ToolStripMenuItem Tool_NewLogon;
        private System.Windows.Forms.ToolStripMenuItem Tool_Setup;
        private System.Windows.Forms.ToolStripMenuItem Menu_9;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Button_Stufind;
        private System.Windows.Forms.ToolStripButton Button_ClewBargain;
        private System.Windows.Forms.ToolStripSeparator toolStripButton4;
        private System.Windows.Forms.ToolStripButton Botton_AddressBook;
        private System.Windows.Forms.ToolStripButton Botton_DayWordPad;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton Button_Close;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ToolStripMenuItem Menu_2;
        private System.Windows.Forms.ToolStripMenuItem Menu_3;
        private System.Windows.Forms.ToolStripMenuItem Tool_Help;
        private System.Windows.Forms.ToolStripMenuItem Tool_Folk;
        private System.Windows.Forms.ToolStripMenuItem Tool_EmployeeGenre;
        private System.Windows.Forms.ToolStripMenuItem Tool_Kultur;
        private System.Windows.Forms.ToolStripMenuItem Tool_Visage;
        private System.Windows.Forms.ToolStripMenuItem Tool_Branch;
        private System.Windows.Forms.ToolStripMenuItem Tool_Laborage;
        private System.Windows.Forms.ToolStripMenuItem Tool_Business;
        private System.Windows.Forms.ToolStripMenuItem Tool_Duthcall;
        private System.Windows.Forms.ToolStripMenuItem Tool_RPKind;
        private System.Windows.Forms.ToolStripMenuItem Tool_WordPad;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripButton Button_Stuffbasic;
        private System.Windows.Forms.ToolStripMenuItem Tool_ClewBirthday;
        private System.Windows.Forms.ToolStripMenuItem Tool_ClewBargain;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

