﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PWMS.DataClass    //封装了系统中所以与数据库连接的方法
{
    class MyMeans
    {
        #region 全局变量
        public static string Login_ID = "";     //定义全局变量，记录当前登录的用户编码
        public static string Login_Name = "";   //定义全局变量，记录当前登录的用户名

        //定义静态全局变量，记录”基础信息“各窗口中的表名、sql语句和要添加修改的字段名
        public static string Mean_SQL = "", Mean_Table = "", Mean_Field = "";

        //定义一个SqlConnection类型的公共变量My_con，用于判断数据库是否连接成功
        public static SqlConnection My_con;

        //定义sql连接字符串，记得改成自己的SQL服务器名字
        public static string M_str_sqlcon = "server=YHC;Initial Catalog=db_PWMS;Integrated Security=True";//我安装的没用密码
        
        //用户登录与重新登陆的标识
        public static int Login_n = 0;
        
        //存储职工基本信息表中的SQL语句
        public static string AllSql = "Select * from tb_Stuffbasic";
        #endregion
        /// <summary>
        /// 建立数据库链接
        /// </summary>
        /// <returns></returns>
        public static SqlConnection getcon()
        {
            My_con = new SqlConnection(M_str_sqlcon);
            My_con.Open();
            return My_con;
        }
        /// <summary>
        /// 测试数据库是否赋加
        /// </summary>
        public void con_open()
        {
            getcon();
            //con_close();
        }
        /// <summary>
        /// 关闭数据库连接
        /// </summary>
        public void con_close()
        {
            if(My_con.State==System.Data.ConnectionState.Open)
            {
                My_con.Close();
                My_con.Dispose();//释放该变量所有空间
            }
        }
        /// <summary>
        /// 只读的方式读取指定表中的信息
        /// </summary>
        /// <param name="SQLstr"></param>
        /// <returns></returns>
        public SqlDataReader getcom(string SQLstr)
        {
            getcon();   //打开与数据库的连接
            SqlCommand My_com = My_con.CreateCommand(); //创建一个SqlCommand对象，用于执行SQL语句
            My_com.CommandText = SQLstr;    //获取指定的SQL语句
            SqlDataReader My_read = My_com.ExecuteReader(); //执行SQL语名句，生成一个SqlDataReader对象
            return My_read;
        }
        /// <summary>
        /// 执行SqlCommand
        /// </summary>
        /// <param name="SQLstr"></param>
        public void getsqlcom(string SQLstr)
        {
            getcon();   
            SqlCommand SQLcom = new SqlCommand(SQLstr, My_con); //创建一个SqlCommand对象，用于执行SQL语句
            SQLcom.ExecuteNonQuery();   //执行SQL语句
            SQLcom.Dispose();   //释放所有空间
            con_close();    //关闭与数据库的连接
        }
        /// <summary>
        ///  创建一个DataSet对象
        /// </summary>
        /// <param name="SQLstr"></param>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public DataSet getDataSet(string SQLstr, string tableName)
        {
            getcon();   
            SqlDataAdapter SQLda = new SqlDataAdapter(SQLstr, My_con); //创建SqlDataAdapter对象，并获取指定数据表的信息
            DataSet My_DataSet = new DataSet(); //创建DataSet对象
            SQLda.Fill(My_DataSet, tableName);  //通过SqlDataAdapter的Fill()方法，将数据表信息添加到DataSet中
            con_close();   
            return My_DataSet;  //返回DataSet对象的信息
        }
    }
}
