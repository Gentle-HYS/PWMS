﻿namespace PWMS.PerForm
{
    partial class F_Find
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Find_Laborage = new System.Windows.Forms.ComboBox();
            this.Find_Kultur = new System.Windows.Forms.ComboBox();
            this.Find_Business = new System.Windows.Forms.ComboBox();
            this.Find_Branch = new System.Windows.Forms.ComboBox();
            this.Find_Employee = new System.Windows.Forms.ComboBox();
            this.Find_Duthcall = new System.Windows.Forms.ComboBox();
            this.Find_Visage = new System.Windows.Forms.ComboBox();
            this.Find_Folk = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Find_Speciality = new System.Windows.Forms.ComboBox();
            this.Find_School = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.Find2_WorkDate = new System.Windows.Forms.MaskedTextBox();
            this.Find1_WorkDate = new System.Windows.Forms.MaskedTextBox();
            this.Find_Pact_Y = new System.Windows.Forms.TextBox();
            this.Pact_Y_Sign = new System.Windows.Forms.ComboBox();
            this.Find_M_Pay = new System.Windows.Forms.TextBox();
            this.M_Pay_Sign = new System.Windows.Forms.ComboBox();
            this.Find_City = new System.Windows.Forms.ComboBox();
            this.Find_BeAware = new System.Windows.Forms.ComboBox();
            this.Find_WorkLength = new System.Windows.Forms.TextBox();
            this.WorkLength_Sign = new System.Windows.Forms.ComboBox();
            this.Find_Age = new System.Windows.Forms.TextBox();
            this.Find_Marriage = new System.Windows.Forms.ComboBox();
            this.Age_Sign = new System.Windows.Forms.ComboBox();
            this.Find_Sex = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Find_Laborage);
            this.groupBox1.Controls.Add(this.Find_Kultur);
            this.groupBox1.Controls.Add(this.Find_Business);
            this.groupBox1.Controls.Add(this.Find_Branch);
            this.groupBox1.Controls.Add(this.Find_Employee);
            this.groupBox1.Controls.Add(this.Find_Duthcall);
            this.groupBox1.Controls.Add(this.Find_Visage);
            this.groupBox1.Controls.Add(this.Find_Folk);
            this.groupBox1.Location = new System.Drawing.Point(11, 6);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(649, 138);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本信息";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(411, 106);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 15);
            this.label8.TabIndex = 16;
            this.label8.Text = "职称类别：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 100);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "部门类别：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(432, 70);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 15);
            this.label6.TabIndex = 14;
            this.label6.Text = "工资类别：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(220, 70);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.TabIndex = 13;
            this.label5.Text = "职务类别：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 70);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "职工类别：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(432, 35);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "政治面貌：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(220, 35);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "文化程度：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "民族类别：";
            // 
            // Find_Laborage
            // 
            this.Find_Laborage.FormattingEnabled = true;
            this.Find_Laborage.Location = new System.Drawing.Point(520, 64);
            this.Find_Laborage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Laborage.Name = "Find_Laborage";
            this.Find_Laborage.Size = new System.Drawing.Size(115, 23);
            this.Find_Laborage.TabIndex = 8;
            // 
            // Find_Kultur
            // 
            this.Find_Kultur.FormattingEnabled = true;
            this.Find_Kultur.Location = new System.Drawing.Point(308, 29);
            this.Find_Kultur.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Kultur.Name = "Find_Kultur";
            this.Find_Kultur.Size = new System.Drawing.Size(115, 23);
            this.Find_Kultur.TabIndex = 7;
            // 
            // Find_Business
            // 
            this.Find_Business.FormattingEnabled = true;
            this.Find_Business.Location = new System.Drawing.Point(308, 64);
            this.Find_Business.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Business.Name = "Find_Business";
            this.Find_Business.Size = new System.Drawing.Size(115, 23);
            this.Find_Business.TabIndex = 6;
            // 
            // Find_Branch
            // 
            this.Find_Branch.FormattingEnabled = true;
            this.Find_Branch.Location = new System.Drawing.Point(96, 96);
            this.Find_Branch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Branch.Name = "Find_Branch";
            this.Find_Branch.Size = new System.Drawing.Size(115, 23);
            this.Find_Branch.TabIndex = 4;
            // 
            // Find_Employee
            // 
            this.Find_Employee.FormattingEnabled = true;
            this.Find_Employee.Location = new System.Drawing.Point(96, 64);
            this.Find_Employee.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Employee.Name = "Find_Employee";
            this.Find_Employee.Size = new System.Drawing.Size(115, 23);
            this.Find_Employee.TabIndex = 3;
            // 
            // Find_Duthcall
            // 
            this.Find_Duthcall.FormattingEnabled = true;
            this.Find_Duthcall.Location = new System.Drawing.Point(520, 96);
            this.Find_Duthcall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Duthcall.Name = "Find_Duthcall";
            this.Find_Duthcall.Size = new System.Drawing.Size(115, 23);
            this.Find_Duthcall.TabIndex = 2;
            // 
            // Find_Visage
            // 
            this.Find_Visage.FormattingEnabled = true;
            this.Find_Visage.Location = new System.Drawing.Point(520, 29);
            this.Find_Visage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Visage.Name = "Find_Visage";
            this.Find_Visage.Size = new System.Drawing.Size(115, 23);
            this.Find_Visage.TabIndex = 1;
            // 
            // Find_Folk
            // 
            this.Find_Folk.FormattingEnabled = true;
            this.Find_Folk.Location = new System.Drawing.Point(96, 29);
            this.Find_Folk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Folk.Name = "Find_Folk";
            this.Find_Folk.Size = new System.Drawing.Size(115, 23);
            this.Find_Folk.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Find_Speciality);
            this.groupBox2.Controls.Add(this.Find_School);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.Find2_WorkDate);
            this.groupBox2.Controls.Add(this.Find1_WorkDate);
            this.groupBox2.Controls.Add(this.Find_Pact_Y);
            this.groupBox2.Controls.Add(this.Pact_Y_Sign);
            this.groupBox2.Controls.Add(this.Find_M_Pay);
            this.groupBox2.Controls.Add(this.M_Pay_Sign);
            this.groupBox2.Controls.Add(this.Find_City);
            this.groupBox2.Controls.Add(this.Find_BeAware);
            this.groupBox2.Controls.Add(this.Find_WorkLength);
            this.groupBox2.Controls.Add(this.WorkLength_Sign);
            this.groupBox2.Controls.Add(this.Find_Age);
            this.groupBox2.Controls.Add(this.Find_Marriage);
            this.groupBox2.Controls.Add(this.Age_Sign);
            this.groupBox2.Controls.Add(this.Find_Sex);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(11, 151);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(649, 164);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "个人信息";
            // 
            // Find_Speciality
            // 
            this.Find_Speciality.FormattingEnabled = true;
            this.Find_Speciality.Location = new System.Drawing.Point(395, 125);
            this.Find_Speciality.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Speciality.Name = "Find_Speciality";
            this.Find_Speciality.Size = new System.Drawing.Size(240, 23);
            this.Find_Speciality.TabIndex = 28;
            // 
            // Find_School
            // 
            this.Find_School.FormattingEnabled = true;
            this.Find_School.Location = new System.Drawing.Point(93, 125);
            this.Find_School.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_School.Name = "Find_School";
            this.Find_School.Size = new System.Drawing.Size(212, 23);
            this.Find_School.TabIndex = 27;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(312, 131);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(82, 15);
            this.label21.TabIndex = 26;
            this.label21.Text = "主修专业：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 131);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 15);
            this.label20.TabIndex = 25;
            this.label20.Text = "毕业学校：";
            // 
            // Find2_WorkDate
            // 
            this.Find2_WorkDate.Location = new System.Drawing.Point(503, 91);
            this.Find2_WorkDate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find2_WorkDate.Name = "Find2_WorkDate";
            this.Find2_WorkDate.Size = new System.Drawing.Size(132, 25);
            this.Find2_WorkDate.TabIndex = 24;
            this.Find2_WorkDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Find2_WorkDate_KeyPress);
            this.Find2_WorkDate.Leave += new System.EventHandler(this.Find2_WorkDate_Leave);
            // 
            // Find1_WorkDate
            // 
            this.Find1_WorkDate.Location = new System.Drawing.Point(339, 91);
            this.Find1_WorkDate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find1_WorkDate.Name = "Find1_WorkDate";
            this.Find1_WorkDate.Size = new System.Drawing.Size(132, 25);
            this.Find1_WorkDate.TabIndex = 23;
            this.Find1_WorkDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Find1_WorkDate_KeyPress);
            this.Find1_WorkDate.Leave += new System.EventHandler(this.Find1_WorkDate_Leave);
            // 
            // Find_Pact_Y
            // 
            this.Find_Pact_Y.Location = new System.Drawing.Point(180, 92);
            this.Find_Pact_Y.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Pact_Y.Name = "Find_Pact_Y";
            this.Find_Pact_Y.Size = new System.Drawing.Size(47, 25);
            this.Find_Pact_Y.TabIndex = 22;
            this.Find_Pact_Y.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Find_Pact_Y_KeyPress);
            // 
            // Pact_Y_Sign
            // 
            this.Pact_Y_Sign.FormattingEnabled = true;
            this.Pact_Y_Sign.Items.AddRange(new object[] {
            "=",
            "<",
            ">",
            "<=",
            ">=",
            "!="});
            this.Pact_Y_Sign.Location = new System.Drawing.Point(93, 92);
            this.Pact_Y_Sign.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Pact_Y_Sign.Name = "Pact_Y_Sign";
            this.Pact_Y_Sign.Size = new System.Drawing.Size(77, 23);
            this.Pact_Y_Sign.TabIndex = 21;
            // 
            // Find_M_Pay
            // 
            this.Find_M_Pay.Location = new System.Drawing.Point(525, 58);
            this.Find_M_Pay.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_M_Pay.Name = "Find_M_Pay";
            this.Find_M_Pay.Size = new System.Drawing.Size(109, 25);
            this.Find_M_Pay.TabIndex = 20;
            this.Find_M_Pay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Find_M_Pay_KeyPress);
            // 
            // M_Pay_Sign
            // 
            this.M_Pay_Sign.FormattingEnabled = true;
            this.M_Pay_Sign.Items.AddRange(new object[] {
            "=",
            "<",
            ">",
            "<=",
            ">=",
            "!="});
            this.M_Pay_Sign.Location = new System.Drawing.Point(447, 58);
            this.M_Pay_Sign.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.M_Pay_Sign.Name = "M_Pay_Sign";
            this.M_Pay_Sign.Size = new System.Drawing.Size(71, 23);
            this.M_Pay_Sign.TabIndex = 19;
            // 
            // Find_City
            // 
            this.Find_City.FormattingEnabled = true;
            this.Find_City.Location = new System.Drawing.Point(212, 59);
            this.Find_City.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_City.Name = "Find_City";
            this.Find_City.Size = new System.Drawing.Size(120, 23);
            this.Find_City.TabIndex = 18;
            this.Find_City.SelectedIndexChanged += new System.EventHandler(this.Find_City_SelectedIndexChanged);
            // 
            // Find_BeAware
            // 
            this.Find_BeAware.FormattingEnabled = true;
            this.Find_BeAware.Location = new System.Drawing.Point(60, 59);
            this.Find_BeAware.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_BeAware.Name = "Find_BeAware";
            this.Find_BeAware.Size = new System.Drawing.Size(113, 23);
            this.Find_BeAware.TabIndex = 17;
            this.Find_BeAware.TextChanged += new System.EventHandler(this.Find_BeAware_TextChanged);
            // 
            // Find_WorkLength
            // 
            this.Find_WorkLength.Location = new System.Drawing.Point(583, 25);
            this.Find_WorkLength.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_WorkLength.Name = "Find_WorkLength";
            this.Find_WorkLength.Size = new System.Drawing.Size(52, 25);
            this.Find_WorkLength.TabIndex = 16;
            this.Find_WorkLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Find_WorkLength_KeyPress);
            // 
            // WorkLength_Sign
            // 
            this.WorkLength_Sign.FormattingEnabled = true;
            this.WorkLength_Sign.Items.AddRange(new object[] {
            "=",
            "<",
            ">",
            "<=",
            ">=",
            "!="});
            this.WorkLength_Sign.Location = new System.Drawing.Point(507, 25);
            this.WorkLength_Sign.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.WorkLength_Sign.Name = "WorkLength_Sign";
            this.WorkLength_Sign.Size = new System.Drawing.Size(69, 23);
            this.WorkLength_Sign.TabIndex = 15;
            // 
            // Find_Age
            // 
            this.Find_Age.Location = new System.Drawing.Point(392, 25);
            this.Find_Age.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Age.Name = "Find_Age";
            this.Find_Age.Size = new System.Drawing.Size(51, 25);
            this.Find_Age.TabIndex = 14;
            this.Find_Age.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Find_Age_KeyPress);
            // 
            // Find_Marriage
            // 
            this.Find_Marriage.FormattingEnabled = true;
            this.Find_Marriage.Items.AddRange(new object[] {
            "已",
            "未"});
            this.Find_Marriage.Location = new System.Drawing.Point(184, 25);
            this.Find_Marriage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Marriage.Name = "Find_Marriage";
            this.Find_Marriage.Size = new System.Drawing.Size(61, 23);
            this.Find_Marriage.TabIndex = 13;
            // 
            // Age_Sign
            // 
            this.Age_Sign.FormattingEnabled = true;
            this.Age_Sign.Items.AddRange(new object[] {
            "=",
            ">",
            "<",
            ">=",
            "<=",
            "!="});
            this.Age_Sign.Location = new System.Drawing.Point(315, 25);
            this.Age_Sign.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Age_Sign.Name = "Age_Sign";
            this.Age_Sign.Size = new System.Drawing.Size(69, 23);
            this.Age_Sign.TabIndex = 12;
            // 
            // Find_Sex
            // 
            this.Find_Sex.FormattingEnabled = true;
            this.Find_Sex.Items.AddRange(new object[] {
            "男",
            "女"});
            this.Find_Sex.Location = new System.Drawing.Point(60, 25);
            this.Find_Sex.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Find_Sex.Name = "Find_Sex";
            this.Find_Sex.Size = new System.Drawing.Size(61, 23);
            this.Find_Sex.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(256, 99);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 15);
            this.label19.TabIndex = 10;
            this.label19.Text = "工作时间：";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(476, 99);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(22, 15);
            this.label18.TabIndex = 9;
            this.label18.Text = "至";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(381, 65);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 15);
            this.label17.TabIndex = 8;
            this.label17.Text = "月工资：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(336, 65);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 15);
            this.label16.TabIndex = 7;
            this.label16.Text = "市";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 99);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 15);
            this.label15.TabIndex = 6;
            this.label15.Text = "合同年限：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(177, 65);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(22, 15);
            this.label14.TabIndex = 5;
            this.label14.Text = "省";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(456, 31);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 15);
            this.label13.TabIndex = 4;
            this.label13.Text = "工龄：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 65);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 15);
            this.label12.TabIndex = 3;
            this.label12.Text = "籍贯：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(264, 31);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "年龄：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(133, 31);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 15);
            this.label10.TabIndex = 1;
            this.label10.Text = "婚姻：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 31);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "性别：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Location = new System.Drawing.Point(668, 6);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(136, 309);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "查询操作";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(20, 159);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(89, 19);
            this.checkBox1.TabIndex = 22;
            this.checkBox1.Text = "显示全部";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.Click += new System.EventHandler(this.checkBox1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(20, 110);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 29);
            this.button3.TabIndex = 21;
            this.button3.Text = "取消";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(20, 71);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 29);
            this.button2.TabIndex = 20;
            this.button2.Text = "清空";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(20, 30);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 29);
            this.button1.TabIndex = 19;
            this.button1.Text = "查询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(25, 270);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(73, 19);
            this.radioButton2.TabIndex = 18;
            this.radioButton2.Text = "或运算";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(25, 241);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(73, 19);
            this.radioButton1.TabIndex = 17;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "与运算";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridView1);
            this.groupBox4.Location = new System.Drawing.Point(11, 322);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(793, 231);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "查询结果";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 28);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(771, 191);
            this.dataGridView1.TabIndex = 0;
            // 
            // F_Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 562);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "F_Find";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "F_Find";
            this.Load += new System.EventHandler(this.F_Find_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox Find_Laborage;
        private System.Windows.Forms.ComboBox Find_Kultur;
        private System.Windows.Forms.ComboBox Find_Business;
        private System.Windows.Forms.ComboBox Find_Branch;
        private System.Windows.Forms.ComboBox Find_Employee;
        private System.Windows.Forms.ComboBox Find_Duthcall;
        private System.Windows.Forms.ComboBox Find_Visage;
        private System.Windows.Forms.ComboBox Find_Folk;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Find_Age;
        private System.Windows.Forms.ComboBox Find_Marriage;
        private System.Windows.Forms.ComboBox Age_Sign;
        private System.Windows.Forms.ComboBox Find_Sex;
        private System.Windows.Forms.TextBox Find_WorkLength;
        private System.Windows.Forms.ComboBox WorkLength_Sign;
        private System.Windows.Forms.ComboBox Find_City;
        private System.Windows.Forms.ComboBox Find_BeAware;
        private System.Windows.Forms.TextBox Find_Pact_Y;
        private System.Windows.Forms.ComboBox Pact_Y_Sign;
        private System.Windows.Forms.TextBox Find_M_Pay;
        private System.Windows.Forms.ComboBox M_Pay_Sign;
        private System.Windows.Forms.MaskedTextBox Find2_WorkDate;
        private System.Windows.Forms.MaskedTextBox Find1_WorkDate;
        private System.Windows.Forms.ComboBox Find_Speciality;
        private System.Windows.Forms.ComboBox Find_School;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}