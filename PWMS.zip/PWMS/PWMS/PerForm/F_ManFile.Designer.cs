﻿namespace PWMS.PerForm
{
    partial class F_ManFile
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_ManFile));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.N_Cauda = new System.Windows.Forms.Button();
            this.N_Next = new System.Windows.Forms.Button();
            this.N_Previous = new System.Windows.Forms.Button();
            this.N_First = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Col_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Col_StuffName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Sub_Excel = new System.Windows.Forms.Button();
            this.Sub_Table = new System.Windows.Forms.Button();
            this.Sut_Save = new System.Windows.Forms.Button();
            this.Sut_Cancel = new System.Windows.Forms.Button();
            this.Sut_Delete = new System.Windows.Forms.Button();
            this.Sut_Amend = new System.Windows.Forms.Button();
            this.Sut_Add = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.S_8 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.S_29 = new System.Windows.Forms.TextBox();
            this.S_28 = new System.Windows.Forms.MaskedTextBox();
            this.S_27 = new System.Windows.Forms.MaskedTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.S_26 = new System.Windows.Forms.TextBox();
            this.S_25 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.S_13 = new System.Windows.Forms.ComboBox();
            this.S_12 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.Img_Save = new System.Windows.Forms.Button();
            this.S_22 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.Img_Clear = new System.Windows.Forms.Button();
            this.S_20 = new System.Windows.Forms.TextBox();
            this.S_19 = new System.Windows.Forms.TextBox();
            this.S_21 = new System.Windows.Forms.MaskedTextBox();
            this.S_18 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.S_Photo = new System.Windows.Forms.PictureBox();
            this.S_16 = new System.Windows.Forms.ComboBox();
            this.S_14 = new System.Windows.Forms.ComboBox();
            this.S_15 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.S_24 = new System.Windows.Forms.ComboBox();
            this.S_23 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.S_10 = new System.Windows.Forms.MaskedTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.S_7 = new System.Windows.Forms.ComboBox();
            this.S_6 = new System.Windows.Forms.ComboBox();
            this.S_5 = new System.Windows.Forms.ComboBox();
            this.S_17 = new System.Windows.Forms.TextBox();
            this.S_11 = new System.Windows.Forms.TextBox();
            this.S_9 = new System.Windows.Forms.TextBox();
            this.S_4 = new System.Windows.Forms.TextBox();
            this.S_3 = new System.Windows.Forms.MaskedTextBox();
            this.S_2 = new System.Windows.Forms.ComboBox();
            this.S_1 = new System.Windows.Forms.TextBox();
            this.S_0 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.Word_6 = new System.Windows.Forms.TextBox();
            this.Word_5 = new System.Windows.Forms.TextBox();
            this.Word_4 = new System.Windows.Forms.TextBox();
            this.Word_3 = new System.Windows.Forms.MaskedTextBox();
            this.Word_2 = new System.Windows.Forms.MaskedTextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Part_Save = new System.Windows.Forms.Button();
            this.Part_Cancel = new System.Windows.Forms.Button();
            this.Part_Delete = new System.Windows.Forms.Button();
            this.Part_Amend = new System.Windows.Forms.Button();
            this.Part_Add = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.Famity_4 = new System.Windows.Forms.MaskedTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.Famity_5 = new System.Windows.Forms.TextBox();
            this.Famity_8 = new System.Windows.Forms.TextBox();
            this.Famity_7 = new System.Windows.Forms.TextBox();
            this.Famity_6 = new System.Windows.Forms.TextBox();
            this.Famity_3 = new System.Windows.Forms.TextBox();
            this.Famity_2 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.TrainNote_7 = new System.Windows.Forms.TextBox();
            this.TrainNote_9 = new System.Windows.Forms.TextBox();
            this.TrainNote_6 = new System.Windows.Forms.TextBox();
            this.TrainNote_8 = new System.Windows.Forms.TextBox();
            this.TrainNote_4 = new System.Windows.Forms.MaskedTextBox();
            this.TrainNote_3 = new System.Windows.Forms.MaskedTextBox();
            this.TrainNote_5 = new System.Windows.Forms.TextBox();
            this.TrainNote_2 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.RANDP_6 = new System.Windows.Forms.TextBox();
            this.RANDP_4 = new System.Windows.Forms.TextBox();
            this.RANDP_5 = new System.Windows.Forms.MaskedTextBox();
            this.RANDP_3 = new System.Windows.Forms.MaskedTextBox();
            this.RANDP_2 = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.Ind_Mome = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.S_Photo)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Location = new System.Drawing.Point(4, 2);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(605, 56);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "分类查询";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "查询类型：";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(409, 19);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(171, 23);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.TextChanged += new System.EventHandler(this.comboBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(320, 29);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "查询条件：";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "按姓名查询",
            "按性别查询",
            "按民族查询",
            "按文化程度查询",
            "按政治面貌查询",
            "按职工类别查询",
            "按职工职务查询",
            "按职工部门查询",
            "按职称类别查询",
            "按工资类别查询"});
            this.comboBox1.Location = new System.Drawing.Point(117, 19);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(181, 23);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.N_Cauda);
            this.groupBox2.Controls.Add(this.N_Next);
            this.groupBox2.Controls.Add(this.N_Previous);
            this.groupBox2.Controls.Add(this.N_First);
            this.groupBox2.Location = new System.Drawing.Point(617, 2);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(359, 58);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "浏览按钮";
            // 
            // N_Cauda
            // 
            this.N_Cauda.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("N_Cauda.BackgroundImage")));
            this.N_Cauda.Location = new System.Drawing.Point(251, 22);
            this.N_Cauda.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.N_Cauda.Name = "N_Cauda";
            this.N_Cauda.Size = new System.Drawing.Size(76, 29);
            this.N_Cauda.TabIndex = 3;
            this.N_Cauda.UseVisualStyleBackColor = true;
            this.N_Cauda.Click += new System.EventHandler(this.N_Cauda_Click);
            // 
            // N_Next
            // 
            this.N_Next.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("N_Next.BackgroundImage")));
            this.N_Next.Location = new System.Drawing.Point(173, 22);
            this.N_Next.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.N_Next.Name = "N_Next";
            this.N_Next.Size = new System.Drawing.Size(77, 29);
            this.N_Next.TabIndex = 2;
            this.N_Next.UseVisualStyleBackColor = true;
            this.N_Next.Click += new System.EventHandler(this.N_Next_Click);
            // 
            // N_Previous
            // 
            this.N_Previous.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("N_Previous.BackgroundImage")));
            this.N_Previous.Enabled = false;
            this.N_Previous.Location = new System.Drawing.Point(97, 22);
            this.N_Previous.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.N_Previous.Name = "N_Previous";
            this.N_Previous.Size = new System.Drawing.Size(76, 29);
            this.N_Previous.TabIndex = 1;
            this.N_Previous.UseVisualStyleBackColor = true;
            this.N_Previous.Click += new System.EventHandler(this.N_Previous_Click);
            // 
            // N_First
            // 
            this.N_First.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("N_First.BackgroundImage")));
            this.N_First.Enabled = false;
            this.N_First.Location = new System.Drawing.Point(21, 22);
            this.N_First.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.N_First.Name = "N_First";
            this.N_First.Size = new System.Drawing.Size(76, 29);
            this.N_First.TabIndex = 0;
            this.N_First.UseVisualStyleBackColor = true;
            this.N_First.Click += new System.EventHandler(this.N_First_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(4, 60);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(225, 509);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 21);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(199, 29);
            this.button1.TabIndex = 7;
            this.button1.Text = "显示所有信息";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Col_ID,
            this.Col_StuffName});
            this.dataGridView1.Location = new System.Drawing.Point(13, 59);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(199, 399);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEnter);
            // 
            // Col_ID
            // 
            this.Col_ID.DataPropertyName = "ID";
            this.Col_ID.HeaderText = "编号";
            this.Col_ID.MinimumWidth = 6;
            this.Col_ID.Name = "Col_ID";
            this.Col_ID.Width = 125;
            // 
            // Col_StuffName
            // 
            this.Col_StuffName.DataPropertyName = "StuffName";
            this.Col_StuffName.HeaderText = "职工姓名";
            this.Col_StuffName.MinimumWidth = 6;
            this.Col_StuffName.Name = "Col_StuffName";
            this.Col_StuffName.Width = 125;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(95, 470);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(116, 25);
            this.textBox1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 478);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "当前记录：";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.tabControl1);
            this.groupBox4.Location = new System.Drawing.Point(237, 60);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(739, 509);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Sub_Excel);
            this.groupBox5.Controls.Add(this.Sub_Table);
            this.groupBox5.Controls.Add(this.Sut_Save);
            this.groupBox5.Controls.Add(this.Sut_Cancel);
            this.groupBox5.Controls.Add(this.Sut_Delete);
            this.groupBox5.Controls.Add(this.Sut_Amend);
            this.groupBox5.Controls.Add(this.Sut_Add);
            this.groupBox5.Location = new System.Drawing.Point(8, 441);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Size = new System.Drawing.Size(719, 58);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            // 
            // Sub_Excel
            // 
            this.Sub_Excel.Location = new System.Drawing.Point(129, 21);
            this.Sub_Excel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sub_Excel.Name = "Sub_Excel";
            this.Sub_Excel.Size = new System.Drawing.Size(104, 29);
            this.Sub_Excel.TabIndex = 6;
            this.Sub_Excel.Text = "导出Excel";
            this.Sub_Excel.UseVisualStyleBackColor = true;
            this.Sub_Excel.Click += new System.EventHandler(this.Sub_Excel_Click);
            // 
            // Sub_Table
            // 
            this.Sub_Table.Location = new System.Drawing.Point(17, 21);
            this.Sub_Table.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sub_Table.Name = "Sub_Table";
            this.Sub_Table.Size = new System.Drawing.Size(104, 29);
            this.Sub_Table.TabIndex = 5;
            this.Sub_Table.Text = "导出Word";
            this.Sub_Table.UseVisualStyleBackColor = true;
            this.Sub_Table.Click += new System.EventHandler(this.but_Table_Click);
            // 
            // Sut_Save
            // 
            this.Sut_Save.Enabled = false;
            this.Sut_Save.Location = new System.Drawing.Point(620, 21);
            this.Sut_Save.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sut_Save.Name = "Sut_Save";
            this.Sut_Save.Size = new System.Drawing.Size(83, 29);
            this.Sut_Save.TabIndex = 4;
            this.Sut_Save.Text = "保存";
            this.Sut_Save.UseVisualStyleBackColor = true;
            this.Sut_Save.Click += new System.EventHandler(this.Sut_Save_Click);
            // 
            // Sut_Cancel
            // 
            this.Sut_Cancel.Enabled = false;
            this.Sut_Cancel.Location = new System.Drawing.Point(529, 21);
            this.Sut_Cancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sut_Cancel.Name = "Sut_Cancel";
            this.Sut_Cancel.Size = new System.Drawing.Size(83, 29);
            this.Sut_Cancel.TabIndex = 3;
            this.Sut_Cancel.Text = "取消";
            this.Sut_Cancel.UseVisualStyleBackColor = true;
            this.Sut_Cancel.Click += new System.EventHandler(this.Sut_Cancel_Click);
            // 
            // Sut_Delete
            // 
            this.Sut_Delete.Location = new System.Drawing.Point(439, 21);
            this.Sut_Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sut_Delete.Name = "Sut_Delete";
            this.Sut_Delete.Size = new System.Drawing.Size(83, 29);
            this.Sut_Delete.TabIndex = 2;
            this.Sut_Delete.Text = "删除";
            this.Sut_Delete.UseVisualStyleBackColor = true;
            this.Sut_Delete.Click += new System.EventHandler(this.Sut_Delete_Click);
            // 
            // Sut_Amend
            // 
            this.Sut_Amend.Location = new System.Drawing.Point(348, 21);
            this.Sut_Amend.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sut_Amend.Name = "Sut_Amend";
            this.Sut_Amend.Size = new System.Drawing.Size(83, 29);
            this.Sut_Amend.TabIndex = 1;
            this.Sut_Amend.Text = "修改";
            this.Sut_Amend.UseVisualStyleBackColor = true;
            this.Sut_Amend.Click += new System.EventHandler(this.Sut_Amend_Click);
            // 
            // Sut_Add
            // 
            this.Sut_Add.Location = new System.Drawing.Point(257, 21);
            this.Sut_Add.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sut_Add.Name = "Sut_Add";
            this.Sut_Add.Size = new System.Drawing.Size(83, 29);
            this.Sut_Add.TabIndex = 0;
            this.Sut_Add.Text = "添加";
            this.Sut_Add.UseVisualStyleBackColor = true;
            this.Sut_Add.Click += new System.EventHandler(this.Sut_Add_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(8, 21);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(719, 418);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Click += new System.EventHandler(this.tabControl1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.S_8);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.S_29);
            this.tabPage1.Controls.Add(this.S_28);
            this.tabPage1.Controls.Add(this.S_27);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.label33);
            this.tabPage1.Controls.Add(this.label32);
            this.tabPage1.Controls.Add(this.S_26);
            this.tabPage1.Controls.Add(this.S_25);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.S_13);
            this.tabPage1.Controls.Add(this.S_12);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.Img_Save);
            this.tabPage1.Controls.Add(this.S_22);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.Img_Clear);
            this.tabPage1.Controls.Add(this.S_20);
            this.tabPage1.Controls.Add(this.S_19);
            this.tabPage1.Controls.Add(this.S_21);
            this.tabPage1.Controls.Add(this.S_18);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.S_Photo);
            this.tabPage1.Controls.Add(this.S_16);
            this.tabPage1.Controls.Add(this.S_14);
            this.tabPage1.Controls.Add(this.S_15);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.S_24);
            this.tabPage1.Controls.Add(this.S_23);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.S_10);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.S_7);
            this.tabPage1.Controls.Add(this.S_6);
            this.tabPage1.Controls.Add(this.S_5);
            this.tabPage1.Controls.Add(this.S_17);
            this.tabPage1.Controls.Add(this.S_11);
            this.tabPage1.Controls.Add(this.S_9);
            this.tabPage1.Controls.Add(this.S_4);
            this.tabPage1.Controls.Add(this.S_3);
            this.tabPage1.Controls.Add(this.S_2);
            this.tabPage1.Controls.Add(this.S_1);
            this.tabPage1.Controls.Add(this.S_0);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(711, 389);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "职工基本信息";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(135, 155);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 15);
            this.label16.TabIndex = 88;
            this.label16.Text = "籍贯：";
            // 
            // S_8
            // 
            this.S_8.FormattingEnabled = true;
            this.S_8.Location = new System.Drawing.Point(415, 82);
            this.S_8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_8.Name = "S_8";
            this.S_8.Size = new System.Drawing.Size(91, 23);
            this.S_8.TabIndex = 38;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(331, 91);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 15);
            this.label12.TabIndex = 87;
            this.label12.Text = "政治面貌：";
            // 
            // S_29
            // 
            this.S_29.Location = new System.Drawing.Point(440, 280);
            this.S_29.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_29.Name = "S_29";
            this.S_29.Size = new System.Drawing.Size(53, 25);
            this.S_29.TabIndex = 86;
            this.S_29.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_Pact_Y_KeyPress);
            // 
            // S_28
            // 
            this.S_28.Location = new System.Drawing.Point(229, 281);
            this.S_28.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_28.Name = "S_28";
            this.S_28.Size = new System.Drawing.Size(116, 25);
            this.S_28.TabIndex = 85;
            this.S_28.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_Pact_E_KeyPress);
            this.S_28.Leave += new System.EventHandler(this.S_Pact_E_Leave);
            // 
            // S_27
            // 
            this.S_27.Location = new System.Drawing.Point(69, 281);
            this.S_27.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_27.Name = "S_27";
            this.S_27.Size = new System.Drawing.Size(120, 25);
            this.S_27.TabIndex = 84;
            this.S_27.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_Pact_B_KeyPress);
            this.S_27.Leave += new System.EventHandler(this.S_Pact_B_Leave);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(353, 288);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(82, 15);
            this.label34.TabIndex = 83;
            this.label34.Text = "合同年限：";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(199, 288);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(22, 15);
            this.label33.TabIndex = 82;
            this.label33.Text = "至";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(13, 288);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(52, 15);
            this.label32.TabIndex = 81;
            this.label32.Text = "合同：";
            // 
            // S_26
            // 
            this.S_26.Location = new System.Drawing.Point(279, 214);
            this.S_26.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_26.Name = "S_26";
            this.S_26.Size = new System.Drawing.Size(227, 25);
            this.S_26.TabIndex = 80;
            // 
            // S_25
            // 
            this.S_25.Location = new System.Drawing.Point(83, 214);
            this.S_25.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_25.Name = "S_25";
            this.S_25.Size = new System.Drawing.Size(91, 25);
            this.S_25.TabIndex = 79;
            this.S_25.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_M_Pay_KeyPress);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(189, 220);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(82, 15);
            this.label31.TabIndex = 78;
            this.label31.Text = "银行账号：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(12, 220);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 15);
            this.label30.TabIndex = 77;
            this.label30.Text = "月工资：";
            // 
            // S_13
            // 
            this.S_13.FormattingEnabled = true;
            this.S_13.Location = new System.Drawing.Point(351, 181);
            this.S_13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_13.Name = "S_13";
            this.S_13.Size = new System.Drawing.Size(155, 23);
            this.S_13.TabIndex = 76;
            // 
            // S_12
            // 
            this.S_12.FormattingEnabled = true;
            this.S_12.Location = new System.Drawing.Point(545, 248);
            this.S_12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_12.Name = "S_12";
            this.S_12.Size = new System.Drawing.Size(147, 23);
            this.S_12.TabIndex = 75;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(261, 189);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 15);
            this.label18.TabIndex = 74;
            this.label18.Text = "职务类别：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(461, 255);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 15);
            this.label20.TabIndex = 73;
            this.label20.Text = "职工类别：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(331, 155);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(22, 15);
            this.label19.TabIndex = 72;
            this.label19.Text = "省";
            // 
            // Img_Save
            // 
            this.Img_Save.Enabled = false;
            this.Img_Save.Location = new System.Drawing.Point(521, 211);
            this.Img_Save.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Img_Save.Name = "Img_Save";
            this.Img_Save.Size = new System.Drawing.Size(100, 29);
            this.Img_Save.TabIndex = 71;
            this.Img_Save.Text = "选择图片";
            this.Img_Save.UseVisualStyleBackColor = true;
            this.Img_Save.Click += new System.EventHandler(this.button7_Click);
            // 
            // S_22
            // 
            this.S_22.Location = new System.Drawing.Point(383, 349);
            this.S_22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_22.Name = "S_22";
            this.S_22.Size = new System.Drawing.Size(309, 25);
            this.S_22.TabIndex = 70;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(296, 359);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(82, 15);
            this.label29.TabIndex = 69;
            this.label29.Text = "家庭地址：";
            // 
            // Img_Clear
            // 
            this.Img_Clear.Enabled = false;
            this.Img_Clear.Location = new System.Drawing.Point(633, 211);
            this.Img_Clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Img_Clear.Name = "Img_Clear";
            this.Img_Clear.Size = new System.Drawing.Size(60, 29);
            this.Img_Clear.TabIndex = 68;
            this.Img_Clear.Text = "清除";
            this.Img_Clear.UseVisualStyleBackColor = true;
            this.Img_Clear.Click += new System.EventHandler(this.button8_Click);
            // 
            // S_20
            // 
            this.S_20.Location = new System.Drawing.Point(96, 351);
            this.S_20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_20.Name = "S_20";
            this.S_20.Size = new System.Drawing.Size(191, 25);
            this.S_20.TabIndex = 67;
            // 
            // S_19
            // 
            this.S_19.Location = new System.Drawing.Point(521, 315);
            this.S_19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_19.Name = "S_19";
            this.S_19.Size = new System.Drawing.Size(171, 25);
            this.S_19.TabIndex = 66;
            // 
            // S_21
            // 
            this.S_21.Location = new System.Drawing.Point(317, 315);
            this.S_21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_21.Name = "S_21";
            this.S_21.Size = new System.Drawing.Size(111, 25);
            this.S_21.TabIndex = 65;
            this.S_21.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_GraduateDate_KeyPress);
            this.S_21.Leave += new System.EventHandler(this.S_GraduateDate_Leave);
            // 
            // S_18
            // 
            this.S_18.Location = new System.Drawing.Point(71, 316);
            this.S_18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_18.Name = "S_18";
            this.S_18.Size = new System.Drawing.Size(149, 25);
            this.S_18.TabIndex = 64;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(13, 359);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(82, 15);
            this.label28.TabIndex = 63;
            this.label28.Text = "主修专业：";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(437, 320);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(82, 15);
            this.label27.TabIndex = 62;
            this.label27.Text = "毕业学校：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(231, 320);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(82, 15);
            this.label26.TabIndex = 61;
            this.label26.Text = "毕业时间：";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(13, 324);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 15);
            this.label25.TabIndex = 60;
            this.label25.Text = "手机：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(503, 288);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 15);
            this.label24.TabIndex = 59;
            this.label24.Text = "电话：";
            // 
            // S_Photo
            // 
            this.S_Photo.BackColor = System.Drawing.Color.LavenderBlush;
            this.S_Photo.Location = new System.Drawing.Point(521, 18);
            this.S_Photo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_Photo.Name = "S_Photo";
            this.S_Photo.Size = new System.Drawing.Size(172, 186);
            this.S_Photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.S_Photo.TabIndex = 58;
            this.S_Photo.TabStop = false;
            this.S_Photo.Click += new System.EventHandler(this.S_Photo_Click);
            // 
            // S_16
            // 
            this.S_16.FormattingEnabled = true;
            this.S_16.Location = new System.Drawing.Point(317, 248);
            this.S_16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_16.Name = "S_16";
            this.S_16.Size = new System.Drawing.Size(133, 23);
            this.S_16.TabIndex = 57;
            // 
            // S_14
            // 
            this.S_14.FormattingEnabled = true;
            this.S_14.Location = new System.Drawing.Point(97, 181);
            this.S_14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_14.Name = "S_14";
            this.S_14.Size = new System.Drawing.Size(148, 23);
            this.S_14.TabIndex = 56;
            // 
            // S_15
            // 
            this.S_15.FormattingEnabled = true;
            this.S_15.Location = new System.Drawing.Point(99, 248);
            this.S_15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_15.Name = "S_15";
            this.S_15.Size = new System.Drawing.Size(123, 23);
            this.S_15.TabIndex = 55;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 188);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(82, 15);
            this.label23.TabIndex = 54;
            this.label23.Text = "工资类别：";
            // 
            // S_24
            // 
            this.S_24.FormattingEnabled = true;
            this.S_24.Location = new System.Drawing.Point(363, 149);
            this.S_24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_24.Name = "S_24";
            this.S_24.Size = new System.Drawing.Size(115, 23);
            this.S_24.TabIndex = 51;
            // 
            // S_23
            // 
            this.S_23.FormattingEnabled = true;
            this.S_23.Location = new System.Drawing.Point(195, 149);
            this.S_23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_23.Name = "S_23";
            this.S_23.Size = new System.Drawing.Size(131, 23);
            this.S_23.TabIndex = 50;
            this.S_23.TextChanged += new System.EventHandler(this.S_BeAware_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(13, 255);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 15);
            this.label22.TabIndex = 49;
            this.label22.Text = "部门类别：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(231, 255);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(82, 15);
            this.label21.TabIndex = 48;
            this.label21.Text = "职称类别：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(481, 155);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(22, 15);
            this.label17.TabIndex = 44;
            this.label17.Text = "市";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 156);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 15);
            this.label15.TabIndex = 42;
            this.label15.Text = "工龄：";
            // 
            // S_10
            // 
            this.S_10.Location = new System.Drawing.Point(373, 115);
            this.S_10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_10.Name = "S_10";
            this.S_10.Size = new System.Drawing.Size(132, 25);
            this.S_10.TabIndex = 41;
            this.S_10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_Workdate_KeyPress);
            this.S_10.Leave += new System.EventHandler(this.S_Workdate_Leave);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(288, 122);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 15);
            this.label14.TabIndex = 38;
            this.label14.Text = "工作时间：";
            // 
            // S_7
            // 
            this.S_7.FormattingEnabled = true;
            this.S_7.Items.AddRange(new object[] {
            "男",
            "女"});
            this.S_7.Location = new System.Drawing.Point(419, 50);
            this.S_7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_7.Name = "S_7";
            this.S_7.Size = new System.Drawing.Size(87, 23);
            this.S_7.TabIndex = 36;
            // 
            // S_6
            // 
            this.S_6.FormattingEnabled = true;
            this.S_6.Items.AddRange(new object[] {
            "已",
            "未"});
            this.S_6.Location = new System.Drawing.Point(67, 82);
            this.S_6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_6.Name = "S_6";
            this.S_6.Size = new System.Drawing.Size(64, 23);
            this.S_6.TabIndex = 35;
            // 
            // S_5
            // 
            this.S_5.FormattingEnabled = true;
            this.S_5.Location = new System.Drawing.Point(221, 82);
            this.S_5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_5.Name = "S_5";
            this.S_5.Size = new System.Drawing.Size(100, 23);
            this.S_5.TabIndex = 34;
            // 
            // S_17
            // 
            this.S_17.Location = new System.Drawing.Point(564, 281);
            this.S_17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_17.Name = "S_17";
            this.S_17.Size = new System.Drawing.Size(128, 25);
            this.S_17.TabIndex = 33;
            // 
            // S_11
            // 
            this.S_11.Location = new System.Drawing.Point(71, 149);
            this.S_11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_11.Name = "S_11";
            this.S_11.Size = new System.Drawing.Size(48, 25);
            this.S_11.TabIndex = 32;
            this.S_11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_WorkLength_KeyPress);
            // 
            // S_9
            // 
            this.S_9.Location = new System.Drawing.Point(83, 115);
            this.S_9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_9.Name = "S_9";
            this.S_9.Size = new System.Drawing.Size(195, 25);
            this.S_9.TabIndex = 31;
            // 
            // S_4
            // 
            this.S_4.Location = new System.Drawing.Point(293, 50);
            this.S_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_4.Name = "S_4";
            this.S_4.Size = new System.Drawing.Size(56, 25);
            this.S_4.TabIndex = 30;
            this.S_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_Age_KeyPress);
            // 
            // S_3
            // 
            this.S_3.ImeMode = System.Windows.Forms.ImeMode.On;
            this.S_3.Location = new System.Drawing.Point(97, 49);
            this.S_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_3.Name = "S_3";
            this.S_3.Size = new System.Drawing.Size(132, 25);
            this.S_3.TabIndex = 29;
            // 
            // S_2
            // 
            this.S_2.FormattingEnabled = true;
            this.S_2.Location = new System.Drawing.Point(407, 18);
            this.S_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_2.Name = "S_2";
            this.S_2.Size = new System.Drawing.Size(99, 23);
            this.S_2.TabIndex = 27;
            // 
            // S_1
            // 
            this.S_1.Location = new System.Drawing.Point(265, 16);
            this.S_1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_1.Name = "S_1";
            this.S_1.Size = new System.Drawing.Size(81, 25);
            this.S_1.TabIndex = 26;
            // 
            // S_0
            // 
            this.S_0.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.S_0.Location = new System.Drawing.Point(97, 16);
            this.S_0.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.S_0.Name = "S_0";
            this.S_0.ReadOnly = true;
            this.S_0.Size = new System.Drawing.Size(76, 25);
            this.S_0.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 122);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 15);
            this.label13.TabIndex = 24;
            this.label13.Text = "身份证：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(363, 58);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 15);
            this.label11.TabIndex = 22;
            this.label11.Text = "性别：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 90);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 15);
            this.label10.TabIndex = 21;
            this.label10.Text = "婚姻：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(139, 90);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 15);
            this.label9.TabIndex = 20;
            this.label9.Text = "文化程度：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(239, 58);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 15);
            this.label8.TabIndex = 19;
            this.label8.Text = "年龄：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 58);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 18;
            this.label7.Text = "出生日期：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(356, 24);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "民族：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(183, 24);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "职工姓名：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 24);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 15);
            this.label4.TabIndex = 15;
            this.label4.Text = "职工编号：";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(711, 389);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "工作简历";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.dataGridView2);
            this.groupBox8.Location = new System.Drawing.Point(11, 150);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox8.Size = new System.Drawing.Size(689, 174);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "数据表";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 25);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(667, 138);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellEnter);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label36);
            this.groupBox7.Controls.Add(this.Word_6);
            this.groupBox7.Controls.Add(this.Word_5);
            this.groupBox7.Controls.Add(this.Word_4);
            this.groupBox7.Controls.Add(this.Word_3);
            this.groupBox7.Controls.Add(this.Word_2);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.label38);
            this.groupBox7.Controls.Add(this.label37);
            this.groupBox7.Controls.Add(this.label35);
            this.groupBox7.Location = new System.Drawing.Point(11, 9);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox7.Size = new System.Drawing.Size(689, 135);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "简历信息";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(364, 30);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 15);
            this.label36.TabIndex = 10;
            this.label36.Text = "结束时间：";
            // 
            // Word_6
            // 
            this.Word_6.Location = new System.Drawing.Point(149, 98);
            this.Word_6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Word_6.Name = "Word_6";
            this.Word_6.Size = new System.Drawing.Size(477, 25);
            this.Word_6.TabIndex = 9;
            // 
            // Word_5
            // 
            this.Word_5.Location = new System.Drawing.Point(456, 62);
            this.Word_5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Word_5.Name = "Word_5";
            this.Word_5.Size = new System.Drawing.Size(171, 25);
            this.Word_5.TabIndex = 8;
            // 
            // Word_4
            // 
            this.Word_4.Location = new System.Drawing.Point(149, 62);
            this.Word_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Word_4.Name = "Word_4";
            this.Word_4.Size = new System.Drawing.Size(169, 25);
            this.Word_4.TabIndex = 7;
            // 
            // Word_3
            // 
            this.Word_3.Location = new System.Drawing.Point(456, 24);
            this.Word_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Word_3.Name = "Word_3";
            this.Word_3.Size = new System.Drawing.Size(171, 25);
            this.Word_3.TabIndex = 6;
            // 
            // Word_2
            // 
            this.Word_2.Location = new System.Drawing.Point(149, 25);
            this.Word_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Word_2.Name = "Word_2";
            this.Word_2.Size = new System.Drawing.Size(169, 25);
            this.Word_2.TabIndex = 5;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(363, 70);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(52, 15);
            this.label39.TabIndex = 4;
            this.label39.Text = "职务：";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(53, 70);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(52, 15);
            this.label38.TabIndex = 3;
            this.label38.Text = "部门：";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(51, 105);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(82, 15);
            this.label37.TabIndex = 2;
            this.label37.Text = "工作单位：";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(53, 31);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(82, 15);
            this.label35.TabIndex = 0;
            this.label35.Text = "开始时间：";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Part_Save);
            this.groupBox6.Controls.Add(this.Part_Cancel);
            this.groupBox6.Controls.Add(this.Part_Delete);
            this.groupBox6.Controls.Add(this.Part_Amend);
            this.groupBox6.Controls.Add(this.Part_Add);
            this.groupBox6.Location = new System.Drawing.Point(11, 322);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox6.Size = new System.Drawing.Size(689, 54);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            // 
            // Part_Save
            // 
            this.Part_Save.Location = new System.Drawing.Point(519, 18);
            this.Part_Save.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Part_Save.Name = "Part_Save";
            this.Part_Save.Size = new System.Drawing.Size(100, 29);
            this.Part_Save.TabIndex = 13;
            this.Part_Save.Text = "保存";
            this.Part_Save.UseVisualStyleBackColor = true;
            this.Part_Save.Click += new System.EventHandler(this.Part_Save_Click);
            // 
            // Part_Cancel
            // 
            this.Part_Cancel.Location = new System.Drawing.Point(409, 18);
            this.Part_Cancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Part_Cancel.Name = "Part_Cancel";
            this.Part_Cancel.Size = new System.Drawing.Size(100, 29);
            this.Part_Cancel.TabIndex = 12;
            this.Part_Cancel.Text = "取消";
            this.Part_Cancel.UseVisualStyleBackColor = true;
            this.Part_Cancel.Click += new System.EventHandler(this.Part_Cancel_Click);
            // 
            // Part_Delete
            // 
            this.Part_Delete.Location = new System.Drawing.Point(300, 18);
            this.Part_Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Part_Delete.Name = "Part_Delete";
            this.Part_Delete.Size = new System.Drawing.Size(100, 29);
            this.Part_Delete.TabIndex = 11;
            this.Part_Delete.Text = "删除";
            this.Part_Delete.UseVisualStyleBackColor = true;
            this.Part_Delete.Click += new System.EventHandler(this.Part_Delete_Click);
            // 
            // Part_Amend
            // 
            this.Part_Amend.Location = new System.Drawing.Point(192, 18);
            this.Part_Amend.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Part_Amend.Name = "Part_Amend";
            this.Part_Amend.Size = new System.Drawing.Size(100, 29);
            this.Part_Amend.TabIndex = 7;
            this.Part_Amend.Text = "修改";
            this.Part_Amend.UseVisualStyleBackColor = true;
            this.Part_Amend.Click += new System.EventHandler(this.Part_Amend_Click);
            // 
            // Part_Add
            // 
            this.Part_Add.Location = new System.Drawing.Point(77, 18);
            this.Part_Add.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Part_Add.Name = "Part_Add";
            this.Part_Add.Size = new System.Drawing.Size(100, 29);
            this.Part_Add.TabIndex = 6;
            this.Part_Add.Text = "添加";
            this.Part_Add.UseVisualStyleBackColor = true;
            this.Part_Add.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Size = new System.Drawing.Size(711, 389);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "家庭关系";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.Famity_4);
            this.groupBox10.Controls.Add(this.label45);
            this.groupBox10.Controls.Add(this.label44);
            this.groupBox10.Controls.Add(this.Famity_5);
            this.groupBox10.Controls.Add(this.Famity_8);
            this.groupBox10.Controls.Add(this.Famity_7);
            this.groupBox10.Controls.Add(this.Famity_6);
            this.groupBox10.Controls.Add(this.Famity_3);
            this.groupBox10.Controls.Add(this.Famity_2);
            this.groupBox10.Controls.Add(this.label46);
            this.groupBox10.Controls.Add(this.label43);
            this.groupBox10.Controls.Add(this.label42);
            this.groupBox10.Controls.Add(this.label41);
            this.groupBox10.Controls.Add(this.label40);
            this.groupBox10.Location = new System.Drawing.Point(12, 11);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox10.Size = new System.Drawing.Size(685, 138);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "家庭关系基本信息";
            // 
            // Famity_4
            // 
            this.Famity_4.Location = new System.Drawing.Point(111, 64);
            this.Famity_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Famity_4.Name = "Famity_4";
            this.Famity_4.Size = new System.Drawing.Size(132, 25);
            this.Famity_4.TabIndex = 16;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(23, 108);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(52, 15);
            this.label45.TabIndex = 15;
            this.label45.Text = "电话：";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(433, 71);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(82, 15);
            this.label44.TabIndex = 14;
            this.label44.Text = "政治面貌：";
            // 
            // Famity_5
            // 
            this.Famity_5.Location = new System.Drawing.Point(351, 100);
            this.Famity_5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Famity_5.Name = "Famity_5";
            this.Famity_5.Size = new System.Drawing.Size(309, 25);
            this.Famity_5.TabIndex = 13;
            // 
            // Famity_8
            // 
            this.Famity_8.Location = new System.Drawing.Point(84, 100);
            this.Famity_8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Famity_8.Name = "Famity_8";
            this.Famity_8.Size = new System.Drawing.Size(163, 25);
            this.Famity_8.TabIndex = 12;
            // 
            // Famity_7
            // 
            this.Famity_7.Location = new System.Drawing.Point(528, 64);
            this.Famity_7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Famity_7.Name = "Famity_7";
            this.Famity_7.Size = new System.Drawing.Size(132, 25);
            this.Famity_7.TabIndex = 11;
            // 
            // Famity_6
            // 
            this.Famity_6.Location = new System.Drawing.Point(311, 64);
            this.Famity_6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Famity_6.Name = "Famity_6";
            this.Famity_6.Size = new System.Drawing.Size(111, 25);
            this.Famity_6.TabIndex = 10;
            // 
            // Famity_3
            // 
            this.Famity_3.Location = new System.Drawing.Point(460, 28);
            this.Famity_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Famity_3.Name = "Famity_3";
            this.Famity_3.Size = new System.Drawing.Size(200, 25);
            this.Famity_3.TabIndex = 8;
            // 
            // Famity_2
            // 
            this.Famity_2.Location = new System.Drawing.Point(137, 29);
            this.Famity_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Famity_2.Name = "Famity_2";
            this.Famity_2.Size = new System.Drawing.Size(185, 25);
            this.Famity_2.TabIndex = 7;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(256, 108);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(82, 15);
            this.label46.TabIndex = 6;
            this.label46.Text = "工作单位：";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(252, 71);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 15);
            this.label43.TabIndex = 3;
            this.label43.Text = "职务：";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(23, 71);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(82, 15);
            this.label42.TabIndex = 2;
            this.label42.Text = "出生日期：";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(339, 38);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(112, 15);
            this.label41.TabIndex = 1;
            this.label41.Text = "与本人的关系：";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(23, 38);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(112, 15);
            this.label40.TabIndex = 0;
            this.label40.Text = "家庭成员名称：";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.dataGridView3);
            this.groupBox9.Location = new System.Drawing.Point(12, 156);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox9.Size = new System.Drawing.Size(685, 169);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "数据表";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(12, 25);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(661, 131);
            this.dataGridView3.TabIndex = 0;
            this.dataGridView3.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellEnter);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox12);
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage4.Size = new System.Drawing.Size(711, 389);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "培训记录";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.TrainNote_7);
            this.groupBox12.Controls.Add(this.TrainNote_9);
            this.groupBox12.Controls.Add(this.TrainNote_6);
            this.groupBox12.Controls.Add(this.TrainNote_8);
            this.groupBox12.Controls.Add(this.TrainNote_4);
            this.groupBox12.Controls.Add(this.TrainNote_3);
            this.groupBox12.Controls.Add(this.TrainNote_5);
            this.groupBox12.Controls.Add(this.TrainNote_2);
            this.groupBox12.Controls.Add(this.label54);
            this.groupBox12.Controls.Add(this.label53);
            this.groupBox12.Controls.Add(this.label52);
            this.groupBox12.Controls.Add(this.label51);
            this.groupBox12.Controls.Add(this.label50);
            this.groupBox12.Controls.Add(this.label49);
            this.groupBox12.Controls.Add(this.label48);
            this.groupBox12.Controls.Add(this.label47);
            this.groupBox12.Location = new System.Drawing.Point(12, 11);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox12.Size = new System.Drawing.Size(687, 158);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "陪训基本信息";
            // 
            // TrainNote_7
            // 
            this.TrainNote_7.Location = new System.Drawing.Point(115, 121);
            this.TrainNote_7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_7.Name = "TrainNote_7";
            this.TrainNote_7.Size = new System.Drawing.Size(547, 25);
            this.TrainNote_7.TabIndex = 15;
            // 
            // TrainNote_9
            // 
            this.TrainNote_9.Location = new System.Drawing.Point(533, 89);
            this.TrainNote_9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_9.Name = "TrainNote_9";
            this.TrainNote_9.Size = new System.Drawing.Size(128, 25);
            this.TrainNote_9.TabIndex = 14;
            // 
            // TrainNote_6
            // 
            this.TrainNote_6.Location = new System.Drawing.Point(115, 90);
            this.TrainNote_6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_6.Name = "TrainNote_6";
            this.TrainNote_6.Size = new System.Drawing.Size(356, 25);
            this.TrainNote_6.TabIndex = 13;
            // 
            // TrainNote_8
            // 
            this.TrainNote_8.Location = new System.Drawing.Point(561, 56);
            this.TrainNote_8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_8.Name = "TrainNote_8";
            this.TrainNote_8.Size = new System.Drawing.Size(100, 25);
            this.TrainNote_8.TabIndex = 12;
            this.TrainNote_8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TrainNote_8_KeyPress);
            // 
            // TrainNote_4
            // 
            this.TrainNote_4.Location = new System.Drawing.Point(393, 58);
            this.TrainNote_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_4.Name = "TrainNote_4";
            this.TrainNote_4.Size = new System.Drawing.Size(108, 25);
            this.TrainNote_4.TabIndex = 11;
            // 
            // TrainNote_3
            // 
            this.TrainNote_3.Location = new System.Drawing.Point(148, 58);
            this.TrainNote_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_3.Name = "TrainNote_3";
            this.TrainNote_3.Size = new System.Drawing.Size(120, 25);
            this.TrainNote_3.TabIndex = 10;
            // 
            // TrainNote_5
            // 
            this.TrainNote_5.Location = new System.Drawing.Point(445, 26);
            this.TrainNote_5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_5.Name = "TrainNote_5";
            this.TrainNote_5.Size = new System.Drawing.Size(216, 25);
            this.TrainNote_5.TabIndex = 9;
            // 
            // TrainNote_2
            // 
            this.TrainNote_2.Location = new System.Drawing.Point(115, 25);
            this.TrainNote_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TrainNote_2.Name = "TrainNote_2";
            this.TrainNote_2.Size = new System.Drawing.Size(228, 25);
            this.TrainNote_2.TabIndex = 8;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(27, 129);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(82, 15);
            this.label54.TabIndex = 7;
            this.label54.Text = "培训内容：";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(481, 98);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(52, 15);
            this.label53.TabIndex = 6;
            this.label53.Text = "效果：";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(511, 65);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(52, 15);
            this.label52.TabIndex = 5;
            this.label52.Text = "费用：";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(27, 65);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(112, 15);
            this.label51.TabIndex = 4;
            this.label51.Text = "培训开始时间：";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(277, 65);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(112, 15);
            this.label50.TabIndex = 3;
            this.label50.Text = "培训结束时间：";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(27, 98);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(82, 15);
            this.label49.TabIndex = 2;
            this.label49.Text = "培训单位：";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(357, 34);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(82, 15);
            this.label48.TabIndex = 1;
            this.label48.Text = "培训专业：";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(27, 34);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(82, 15);
            this.label47.TabIndex = 0;
            this.label47.Text = "培训方式：";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.dataGridView4);
            this.groupBox11.Location = new System.Drawing.Point(12, 176);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox11.Size = new System.Drawing.Size(687, 148);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "数据表";
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(11, 25);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(664, 112);
            this.dataGridView4.TabIndex = 0;
            this.dataGridView4.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellEnter);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox14);
            this.tabPage5.Controls.Add(this.groupBox13);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage5.Size = new System.Drawing.Size(711, 389);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "奖惩记录";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.RANDP_6);
            this.groupBox14.Controls.Add(this.RANDP_4);
            this.groupBox14.Controls.Add(this.RANDP_5);
            this.groupBox14.Controls.Add(this.RANDP_3);
            this.groupBox14.Controls.Add(this.RANDP_2);
            this.groupBox14.Controls.Add(this.label59);
            this.groupBox14.Controls.Add(this.label58);
            this.groupBox14.Controls.Add(this.label57);
            this.groupBox14.Controls.Add(this.label56);
            this.groupBox14.Controls.Add(this.label55);
            this.groupBox14.Location = new System.Drawing.Point(15, 8);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox14.Size = new System.Drawing.Size(683, 126);
            this.groupBox14.TabIndex = 1;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "奖惩信息";
            // 
            // RANDP_6
            // 
            this.RANDP_6.AcceptsReturn = true;
            this.RANDP_6.Location = new System.Drawing.Point(327, 80);
            this.RANDP_6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.RANDP_6.Name = "RANDP_6";
            this.RANDP_6.Size = new System.Drawing.Size(336, 25);
            this.RANDP_6.TabIndex = 9;
            // 
            // RANDP_4
            // 
            this.RANDP_4.Location = new System.Drawing.Point(560, 32);
            this.RANDP_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.RANDP_4.Name = "RANDP_4";
            this.RANDP_4.Size = new System.Drawing.Size(103, 25);
            this.RANDP_4.TabIndex = 8;
            // 
            // RANDP_5
            // 
            this.RANDP_5.Location = new System.Drawing.Point(104, 80);
            this.RANDP_5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.RANDP_5.Name = "RANDP_5";
            this.RANDP_5.Size = new System.Drawing.Size(127, 25);
            this.RANDP_5.TabIndex = 7;
            // 
            // RANDP_3
            // 
            this.RANDP_3.Location = new System.Drawing.Point(360, 30);
            this.RANDP_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.RANDP_3.Name = "RANDP_3";
            this.RANDP_3.Size = new System.Drawing.Size(117, 25);
            this.RANDP_3.TabIndex = 6;
            // 
            // RANDP_2
            // 
            this.RANDP_2.FormattingEnabled = true;
            this.RANDP_2.Location = new System.Drawing.Point(104, 32);
            this.RANDP_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.RANDP_2.Name = "RANDP_2";
            this.RANDP_2.Size = new System.Drawing.Size(140, 23);
            this.RANDP_2.TabIndex = 5;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(19, 88);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(82, 15);
            this.label59.TabIndex = 4;
            this.label59.Text = "撤消时间：";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(243, 88);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(82, 15);
            this.label58.TabIndex = 3;
            this.label58.Text = "撤消原因：";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(492, 39);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(67, 15);
            this.label57.TabIndex = 2;
            this.label57.Text = "批准人：";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(257, 39);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(97, 15);
            this.label56.TabIndex = 1;
            this.label56.Text = "奖惩治时间：";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(19, 39);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(82, 15);
            this.label55.TabIndex = 0;
            this.label55.Text = "奖惩种类：";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.dataGridView5);
            this.groupBox13.Location = new System.Drawing.Point(16, 141);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox13.Size = new System.Drawing.Size(683, 181);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "数据表";
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(12, 25);
            this.dataGridView5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.RowTemplate.Height = 23;
            this.dataGridView5.Size = new System.Drawing.Size(659, 145);
            this.dataGridView5.TabIndex = 0;
            this.dataGridView5.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellEnter);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.Ind_Mome);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage6.Size = new System.Drawing.Size(711, 389);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "个人简历";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // Ind_Mome
            // 
            this.Ind_Mome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ind_Mome.Location = new System.Drawing.Point(4, 4);
            this.Ind_Mome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Ind_Mome.Multiline = true;
            this.Ind_Mome.Name = "Ind_Mome";
            this.Ind_Mome.Size = new System.Drawing.Size(703, 381);
            this.Ind_Mome.TabIndex = 0;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // F_ManFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 575);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "F_ManFile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_ManFile";
            this.Load += new System.EventHandler(this.F_ManFile_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.S_Photo)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button N_Cauda;
        private System.Windows.Forms.Button N_Next;
        private System.Windows.Forms.Button N_Previous;
        private System.Windows.Forms.Button N_First;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.MaskedTextBox S_3;
        private System.Windows.Forms.ComboBox S_2;
        private System.Windows.Forms.TextBox S_1;
        private System.Windows.Forms.TextBox S_0;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Sut_Add;
        private System.Windows.Forms.TextBox S_11;
        private System.Windows.Forms.TextBox S_9;
        private System.Windows.Forms.TextBox S_4;
        private System.Windows.Forms.ComboBox S_5;
        private System.Windows.Forms.ComboBox S_7;
        private System.Windows.Forms.ComboBox S_6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox S_10;
        private System.Windows.Forms.ComboBox S_24;
        private System.Windows.Forms.ComboBox S_23;
        private System.Windows.Forms.ComboBox S_14;
        private System.Windows.Forms.PictureBox S_Photo;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox S_20;
        private System.Windows.Forms.TextBox S_19;
        private System.Windows.Forms.Button Img_Clear;
        private System.Windows.Forms.TextBox S_22;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Img_Save;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox S_13;
        private System.Windows.Forms.ComboBox S_12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Col_StuffName;
        private System.Windows.Forms.Button Sut_Save;
        private System.Windows.Forms.Button Sut_Cancel;
        private System.Windows.Forms.Button Sut_Delete;
        private System.Windows.Forms.Button Sut_Amend;
        private System.Windows.Forms.TextBox S_26;
        private System.Windows.Forms.TextBox S_25;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox S_16;
        private System.Windows.Forms.ComboBox S_15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox S_17;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox S_29;
        private System.Windows.Forms.MaskedTextBox S_28;
        private System.Windows.Forms.MaskedTextBox S_27;
        private System.Windows.Forms.MaskedTextBox S_21;
        private System.Windows.Forms.TextBox S_18;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button Part_Amend;
        private System.Windows.Forms.Button Part_Add;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.MaskedTextBox Word_3;
        private System.Windows.Forms.MaskedTextBox Word_2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox Word_6;
        private System.Windows.Forms.TextBox Word_5;
        private System.Windows.Forms.TextBox Word_4;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox Famity_3;
        private System.Windows.Forms.TextBox Famity_2;
        private System.Windows.Forms.TextBox Famity_5;
        private System.Windows.Forms.TextBox Famity_8;
        private System.Windows.Forms.TextBox Famity_7;
        private System.Windows.Forms.TextBox Famity_6;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button Part_Delete;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox S_8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button Part_Cancel;
        private System.Windows.Forms.Button Part_Save;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.MaskedTextBox Famity_4;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox TrainNote_8;
        private System.Windows.Forms.MaskedTextBox TrainNote_4;
        private System.Windows.Forms.MaskedTextBox TrainNote_3;
        private System.Windows.Forms.TextBox TrainNote_5;
        private System.Windows.Forms.TextBox TrainNote_2;
        private System.Windows.Forms.TextBox TrainNote_9;
        private System.Windows.Forms.TextBox TrainNote_6;
        private System.Windows.Forms.TextBox TrainNote_7;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.MaskedTextBox RANDP_3;
        private System.Windows.Forms.ComboBox RANDP_2;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox RANDP_6;
        private System.Windows.Forms.TextBox RANDP_4;
        private System.Windows.Forms.MaskedTextBox RANDP_5;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.TextBox Ind_Mome;
        private System.Windows.Forms.Button Sub_Table;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button Sub_Excel;

    }
}